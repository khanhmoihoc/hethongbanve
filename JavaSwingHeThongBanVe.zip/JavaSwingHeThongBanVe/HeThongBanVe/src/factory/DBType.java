package factory;

public enum DBType {
    POSTGRES,
    MOCK
}
